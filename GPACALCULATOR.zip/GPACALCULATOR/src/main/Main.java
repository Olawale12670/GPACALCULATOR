package main;

import utils.CreateTable;
import models.GetGradeDetails;
import models.GetGradePointAttained;
import models.GetUnitDetails;
import java.util.InputMismatchException;
import java.util.Scanner;

public class Main {
    private static Scanner scanner = new Scanner(System.in);
    public static void main(String[] args) {
        System.out.print("input total courses offered: ");
        int numberOfCourses = totalCourse();

        String[][] courseDetails = new String[numberOfCourses][3];
        for (int i = 0; i < numberOfCourses; i++) {
            String[] newDetails = new String[1];
            newDetails = getDetails(i + 1);
            courseDetails[i] = newDetails;
        }
        
        String[][] gradedCourseProfile = GetGradeDetails.getGradeObtained(courseDetails);
        String[][] gradedUnitCourseProfile = GetUnitDetails.getUnitObtained(gradedCourseProfile);
        double gradePointAverage = GetGradePointAttained.getGradePointObtained(gradedUnitCourseProfile);

        CreateTable.generateTable(gradedUnitCourseProfile);

        String formattedGPA = String.format("%.2f", gradePointAverage);
        System.out.printf("\n\nYour GPA is = %s to 2 decimal places.\n", formattedGPA);

        scanner.close();
    }

    private static int totalCourse() {
        int numberOfCourses = 0;
        try {
            numberOfCourses = scanner.nextInt();
            scanner.nextLine();
        } catch (InputMismatchException e) {
            System.err.println("insert a number not letters");
            scanner.nextLine();
            numberOfCourses = totalCourse();
        }
        return numberOfCourses;
    }
    
    private static String[] getDetails(int index) {
        String[] courseProfile = new String[3];
        String courseName = "";
        int courseCredit = 0;
        int score = 0;

        try {

            System.out.println("insert name of course " + index + ": ");
            if (scanner.hasNextLine()) {
                courseName = scanner.nextLine();
            }

            System.out.println("insert credit unit: ");
            while (!scanner.hasNextInt()) {
                System.err.println("input a number not alphabet.");
                scanner.nextLine();
            }
            courseCredit = scanner.nextInt();
            scanner.nextLine();
            while (courseCredit <= 0 || courseCredit > 6) {
                System.err.println("insert a course credit greater than zero and less than seven");
                courseCredit = scanner.nextInt();
                scanner.nextLine();
            }

            System.out.println("insert score attained: ");
            while (!scanner.hasNextInt()) {
                System.err.println("input a valid score");
                scanner.nextLine();
            }
            score = scanner.nextInt();
            scanner.nextLine();
            while (score < 0 || score > 100) {
                System.err.println("insert a score within 0 and 100");
                score = scanner.nextInt();
                scanner.nextLine();
            }

            // // passing values to the courseprofile array
            courseProfile[0] = courseName;
            courseProfile[1] = String.valueOf(courseCredit); //String.valueOf method helps to typecast an int to string
            courseProfile[2] = String.valueOf(score);
        } catch (InputMismatchException e) {
            System.err.println("input correct details");
            getDetails(index);
        }

        return courseProfile;
    }
}