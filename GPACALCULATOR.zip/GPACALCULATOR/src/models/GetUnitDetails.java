package models;

public class GetUnitDetails {
    public static String[][] getUnitObtained(String[][] gradedProfile) {
        String[][] unitGradedProfile = new String[gradedProfile.length][4];
        for (int i = 0; i < gradedProfile.length; i++) {
            String[] unitProfile = new String[4];

            unitProfile[0] = gradedProfile[i][0];
            unitProfile[1] = gradedProfile[i][1];
            unitProfile[2] = gradedProfile[i][2];

            String grade = gradedProfile[i][2];

            if (grade == "A") {
                unitProfile[3] = "5";
            } else if (grade == "B") {
                unitProfile[3] = "4";
            } else if (grade == "C") {
                unitProfile[3] = "3";
            } else if (grade == "D") {
                unitProfile[3] = "2";
            } else if (grade == "E") {
                unitProfile[3] = "1";
            } else {
                unitProfile[3] = "0";
            }
            unitGradedProfile[i] = unitProfile;
        }

        return unitGradedProfile;
    }
}